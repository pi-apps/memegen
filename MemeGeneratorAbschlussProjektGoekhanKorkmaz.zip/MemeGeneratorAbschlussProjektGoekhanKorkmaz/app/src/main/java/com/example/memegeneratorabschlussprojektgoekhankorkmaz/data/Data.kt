package com.example.memegeneratorabschlussprojektgoekhankorkmaz.data

import androidx.room.Entity
import androidx.room.PrimaryKey


data class Data(
    val memes: List<Meme>
)
