package com.example.memegeneratorabschlussprojektgoekhankorkmaz;

public class BR {
  public static final int _all = 0;
}
