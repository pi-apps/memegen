package androidx.databinding;

public interface DataBindingComponent {
}
