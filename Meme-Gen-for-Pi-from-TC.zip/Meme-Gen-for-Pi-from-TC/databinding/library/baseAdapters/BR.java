package androidx.databinding.library.baseAdapters;

public class BR {
  public static final int _all = 0;
}
